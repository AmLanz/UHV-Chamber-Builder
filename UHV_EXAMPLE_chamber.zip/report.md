# UHV chamber

UHV Chamber Builder 1.3.1 · draft recipe · mm / degrees

Reference/visualization geometry. Fasteners, rotatable inserts and seal profiles may be schematic.

Catalog: MBE-CF-2020-reference@2026-09-29

## Points

| Name | X | Y | Z |
| --- | ---: | ---: | ---: |
| A | 0 | 0 | 0 |
| B | 10 | 0 | 0 |
| C | -100 | 0 | 0 |

## Body shapes

| Name | Shape | Reference | Enabled |
| --- | --- | --- | --- |
| Main Chamber | tube | A | True |
| Sphere | sphere | C | True |

## Flanges

Angle convention: Azimuth from X / elevation around X (negative azimuth selects opposite Y half). Tube-end flanges follow their parent tube.

| Number | Name | Preset | Configuration | Face centre (mm) | Outward normal | OD | Thickness | PCD | Holes | Bore | Tube OD × wall |
| ---: | --- | --- | --- | --- | --- | ---: | ---: | ---: | --- | ---: | --- |
| 2 | Main Chamber / plus | DN200CF | straddled | 100, 0, 0 | 1, 0, 0 | 254.0 | 24.0 | 231.8 | 24 × 8.4 | 200.0 | 206.0 × 3.0 |
| 3 | PooPort | DN40CF | straddled | -290, 2.24964e-30, 3.67394e-14 | -1, 7.4988e-33, 1.22465e-16 | 69.9 | 12.5 | 58.7 | 6 × 6.8 | 35.0 | 38.0 × 1.5 |
| 4 | Top view window | DN40CF | straddled | 51.411, 109.282, 109.282 | 0.258819, 0.683013, 0.683013 | 69.9 | 12.5 | 58.7 | 6 × 6.8 | 35.0 | 38.0 × 1.5 |
| 5 | Pump Falnge | DN100CF | straddled | 1.22465e-14, -51.7638, -193.185 | 6.12323e-17, -0.258819, -0.965926 | 152.4 | 19.5 | 130.3 | 16 × 8.4 | 100.0 | 104.0 × 2.0 |
| 6 | Beam entry | DN40CF | straddled | 51.411, 149.282, -40 | 0.258819, 0.933013, -0.25 | 69.9 | 12.5 | 58.7 | 6 × 6.8 | 35.0 | 38.0 × 1.5 |
| 7 | Focus Cam | DN40CF | straddled | 51.411, 109.282, -109.282 | 0.258819, 0.683013, -0.683013 | 69.9 | 12.5 | 58.7 | 6 × 6.8 | 35.0 | 38.0 × 1.5 |
| 8 | Port 4 copy copy | DN40CF | straddled | 51.411, 40, 149.282 | 0.258819, 0.25, 0.933013 | 69.9 | 12.5 | 58.7 | 6 × 6.8 | 35.0 | 38.0 × 1.5 |
| 9 | Beam Exit | DN40CF | straddled | 51.411, -149.282, 40 | 0.258819, -0.933013, 0.25 | 69.9 | 12.5 | 58.7 | 6 × 6.8 | 35.0 | 38.0 × 1.5 |
| 10 | Sample Microscope | DN40CF | straddled | 51.411, -109.282, 109.282 | 0.258819, -0.683013, 0.683013 | 69.9 | 12.5 | 58.7 | 6 × 6.8 | 35.0 | 38.0 × 1.5 |
| 11 | Pressure gauge | DN40CF | straddled | 51.411, -40, 149.282 | 0.258819, -0.25, 0.933013 | 69.9 | 12.5 | 58.7 | 6 × 6.8 | 35.0 | 38.0 × 1.5 |

## Validation

Input checks passed. This is not a native Fusion interference or structural verification.

The accompanying JSON contains the complete dimensions, overrides and defaults.
